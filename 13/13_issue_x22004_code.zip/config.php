<?php
define('DSN','mysql:host=localhost;dbname=office_db');
define('DB_USER','x22004');
define('DB_PASSWORD','webphp');
