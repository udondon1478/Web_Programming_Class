<?php
define('DSN','mysql:host=localhost;dbname=WP2023_db');
define('DB_USER','x22004');
define('DB_PASSWORD','webphp');
